import NodeReplicate from 'node-replicate';
import fetch from 'node-fetch';

const replicate = new NodeReplicate();

const models = {
  "real-esrgan": "daanelson/real-esrgan-a100:499940604f95b416c3939423df5c64a5c95cfd32b464d755dacfe2192a2de7ef",
  "sdxl": "stability-ai/sdxl:c221b2b8ef527988fb59bf24a8b97c4561f1c671f73bd389f866bfb27c061316",
  "sdxl-70s-scifi": "jakedahn/sdxl-70s-scifi:426affa4cca9beb69b34c92c54133196902a4bf72dba90718f0de3124418eedb",
  "sdxl-barbie": "fofr/sdxl-barbie:657c074cdd0e0098e39dae981194c4e852ad5bc88c7fbbeb0682afae714a6b0e",
  "sdxl-barbietron": "fofr/sdxl-barbietron:e120cde4b3a343dbe5116638645c3a41b4859347c08dbfb8f49bcea7cb91b5fa",
  "sdxl-cross-section": "fofr/sdxl-cross-section:26d3c19f09b63925b3d974d0934cbdf33e7243189f7ff3e281b00930f648fb1d",
  "sdxl-davinci": "cbh123/sdxl-davinci:ee977b1e87cb5423c16acd6525d752c05cbd288cb7f42bfe88e759a6e4487bbc",
  "sdxl-deep-down": "fofr/sdxl-deep-down:b42c6affd67fc88a1f3a8b5c35ae943425508989607f35f39f4ca9b3e7d91ce8",
  "sdxl-emoji": "fofr/sdxl-emoji:dee76b5afde21b0f01ed7925f0665b7e879c50ee718c5f78a9d38e04d523cc5e",
  "sdxl-finland": "pwntus/sdxl-finland:b09b02a0c782de7810af0dadd767c1add7f2e151a054b8c90aeb13ee90fb0629",
  "sdxl-gta-v": "pwntus/sdxl-gta-v:b61a50b07f8316aab4a10253692511dd2f0b6f8546113c314a0e0940dc372614",
  "sdxl-isometric-geology": "jakedahn/sdxl-isometric-geology:44272e4bb4f61d052617d4b56cc5be7b34dc27d9605e4c9568efc215aae547c5",
  "sdxl-jwst": "fofr/sdxl-jwst:3c39ca4c9c8c1b3f1a5839fe46319da49baafeabed07c0741f43ac70e874de54",
  "sdxl-illusions": "cbh123/sdxl-illusions:4d3491c45be12fae0972e28a55ea146cef41b717883641fcd46c60fbfc9641ac",
  "sdxl-simpsons": "fofr/sdxl-simpsons:e080bb23696e6b8b1a354d672927d4131c2ad8dd138081528fc6298d91b94f88",
  "sdxl-sonic-2": "fofr/sdxl-sonic-2:d9b22cdf778d4ccaf2b6a84a06a2eaa754305703d46983e1a996fe1eabbfd26c",
  "sdxl-tron": "fofr/sdxl-tron:fd920825e12db2a942f8a9cac40ad4f624a34a06faba3ac1b44a5305df8c6e2d",
};

async function fetchImageAsBase64(imageUrl) {
  try {
    const response = await fetch(imageUrl);
    if (!response.ok) {
      throw new Error(`Failed to fetch image: ${response.statusText}`);
    }
    const buffer = await response.arrayBuffer();
    return `data:image/png;base64,${Buffer.from(buffer).toString('base64')}`;
  } catch (error) {
    console.error(`Error fetching image as Base64: ${error}`);
    throw error;
  }
}

export default async function runModel(prompt, modelType, additionalOptions, uploaded_image, image_url) {
  const selectedModel = models[modelType];
  if (!selectedModel) {
    console.error(`Invalid modelType: ${modelType}`);
    return;
  }

  // Validate the model identifier format
  const namePattern = /[a-zA-Z0-9]+(?:(?:[._]|__|[-]*)[a-zA-Z0-9]+)*/;
  const pattern = new RegExp(
    `^(?<owner>${namePattern.source})/(?<name>${namePattern.source}):(?<version>[0-9a-fA-F]+)$`
  );
  const match = selectedModel.match(pattern);
  if (!match || !match.groups) {
    throw new Error('Invalid version. It must be in the format "owner/name:version"');
  }

  console.log(`Selected model: ${selectedModel}`);

  const input = { prompt };

  // Handle image inputs
  if (uploaded_image) {
    input.uploaded_image = uploaded_image;
  } else if (image_url) {
    input.image_url = await fetchImageAsBase64(image_url);
  }

  try {
    // Start the prediction and monitor its status
    let prediction = await replicate.create(selectedModel, { input, ...additionalOptions });

    while (!['canceled', 'succeeded', 'failed'].includes(prediction.status)) {
      console.log(`Current prediction status: ${prediction.status}`);
      await new Promise(resolve => setTimeout(resolve, 250));
      prediction = await replicate.get(prediction);
    }

    // Check if the prediction failed
    if (prediction.status === 'failed') {
      throw new Error(`Prediction failed: ${prediction.error}`);
    }

    // Display the final status and outputs
    console.log(`Final prediction status: ${prediction.status}`);
    console.log(`Final prediction output: ${JSON.stringify(prediction.output, null, 2)}`);

    // Return the prediction output
    return prediction.output;
  } catch (error) {
    console.error(`Error running model: ${error}`);
  }
}